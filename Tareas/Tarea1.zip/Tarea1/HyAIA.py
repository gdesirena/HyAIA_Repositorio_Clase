import string
import pandas as pd

class HyAIA:
    def __init__(self, df):
        self.data = df
        self.columns = df.columns
        self.data_binarios, self.binarios_columns = self.get_binarios()
        self.data_cuantitativos, self.cuantitativos_columns = self.get_cuantitativos()
        self.data_categoricos, self.categoricos_columns = self.get_categoricos()
        self.df_dqr = self.dqr()
    
    def dqr(self):
        #% Lista de variables de la base de datos
        columns = pd.DataFrame(list(self.data.columns.values), columns=['Columns_Names'], 
                            index=list(self.data.columns.values))
        
        #Lista de tipos de datos del dataframe
        data_dtypes = pd.DataFrame(self.data.dtypes, columns=['Dtypes'])
        
        #Lista de valores presentes
        present_values = pd.DataFrame(self.data.count(), columns=['Present_values'])
        
        #Lista de valores missing (Valores faltantes/nulos nan)
        missing_values = pd.DataFrame(self.data.isnull().sum(), columns=['Missing_values'])

        porcentaje_presente = self.data.count() / (self.data.isnull().sum() + self.data.count()) * 100
        per_present_values = pd.DataFrame(porcentaje_presente, columns=['% Presents'])

        porcentaje_ausente = self.data.isnull().sum() / (self.data.isnull().sum() + self.data.count()) * 100
        per_missing_values = pd.DataFrame(porcentaje_ausente, columns=['% Missing'])

        
        #Valores unicos de las columnas
        unique_values = pd.DataFrame(columns=['Unique_values'])
        for col in list(self.data.columns.values):
            unique_values.loc[col] = [self.data[col].nunique()]
        
        # Información estadística
        #Lista de valores máximos
        max_values = pd.DataFrame(columns=["Maximo"])
        for col in list(self.data.columns.values):
            try:
                max_values.loc[col] = [self.data[col].max()]
            except Exception:
                max_values.loc[col] = ["N/A"]
                pass

        #Lista de valores mínimos
        min_values = pd.DataFrame(columns=["Minimo"])
        for col in list(self.data.columns.values):
            try:
                min_values.loc[col] = [self.data[col].min()]
            except Exception:
                min_values.loc[col] = ["N/A"]
                pass
        
        #Lista de valores con su desviación estandar
        std_values = pd.DataFrame(columns=["Desv. Std"])
        for col in list(self.data.columns.values):
            try:
                std_values.loc[col] = [self.data[col].std()]
            except Exception:
                std_values.loc[col] = ["N/A"]
                pass
        
        #Lista de valores con su promedio
        mean_values = pd.DataFrame(columns=["Promedio"])
        for col in list(self.data.columns.values):
            try:
                mean_values.loc[col] = [self.data[col].mean()]
            except Exception:
                mean_values.loc[col] = ["N/A"]
                pass
        
        #Lista de valores con los percentiles

        percentil25_values = pd.DataFrame(columns=["P25"])
        for col in self.data.columns:
            try:
                percentil25_values.loc[col] = [self.data[col].quantile(0.25)]
            except Exception:
                percentil25_values.loc[col] = ["N/A"]

        percentil50_values = pd.DataFrame(columns=["P50"])
        for col in self.data.columns:
            try:
                percentil50_values.loc[col] = [self.data[col].quantile(0.5)]
            except Exception:
                percentil50_values.loc[col] = ["N/A"]
        
        percentil75_values = pd.DataFrame(columns=["P75"])
        for col in self.data.columns:
            try:
                percentil75_values.loc[col] = [self.data[col].quantile(0.75)]
            except Exception:
                percentil75_values.loc[col] = ["N/A"]

      
        
        #Lista de valores con la media

        is_categorical = pd.DataFrame(columns=["Is_Categorical"])
        for col in self.data.columns:
            if pd.api.types.is_numeric_dtype(self.data[col]):
                is_categorical.loc[col] = ["NO"]
            else:
                is_categorical.loc[col] = ["SI"]


        categorias_values = pd.DataFrame(columns=["Elementos"])
        for col in list(self.data.columns.values):
            if self.data[col].nunique() < 10:
                categorias_values.loc[col] = [self.data[col].unique()]
            else:
                categorias_values.loc[col] = ["No es posible visualizar > 10 elementos"]
                

        
        return columns.join(data_dtypes).join(present_values).join(per_present_values).join(missing_values).join(per_missing_values).join(unique_values).join(max_values).join(min_values).join(mean_values).join(percentil25_values).join(percentil50_values).join(percentil75_values).join(std_values).join(is_categorical).join(categorias_values)
        
    ##% Métodos para Análisis de Datos 
    #Método para obtener las columnas y dataframe binarios
    def get_binarios(self):
        col_bin = []
        for col in self.data.columns:
            if self.data[col].nunique() == 2:
                col_bin.append(col)

        return self.data[col_bin], col_bin

    #Método para obtener columnas y dataframe cuantitativos
    def get_cuantitativos(self):
        col_numericos = self.data.select_dtypes(include = "number").columns
        return self.data[col_numericos], col_numericos    

    #Método para obtener columnas y dataframe categóricos
    def get_categoricos(self):
        col_categoricos = self.data.select_dtypes(exclude = "number").columns
        col_cat = []
        for col in  col_categoricos:
            if self.data[col].nunique() > 2:
                col_cat.append(col)
        return self.data[col_cat], col_cat
    
    @staticmethod
    def remove_punctuation(x):
        try:
            x = ''.join(ch for ch in x if ch not in string.punctuation)
        except:
            print(f'{x} no es una cadena de caracteres')
            pass
        return x

    @staticmethod
    def remove_digits(x):
        try:
            x=''.join(ch for ch in x if ch not in string.digits)
        except:
            print(f'{x} no es una cadena de caracteres')
            pass
        return x

    @staticmethod
    def remove_whitespace(x):
        try:
            x=' '.join(x.split())
        except:
            pass
        return x

    @staticmethod
    def lower_text(x):
        try:
            x = x.lower()
        except:
            pass
        return x

    @staticmethod
    def upper_text(x):
        try:
            x = x.upper()
        except:
            pass
        return x

    @staticmethod
    def capitalize_text(x):
        try:
            x = x.capitalize()
        except:
            pass
        return x
    
    @staticmethod
    def replace_text(x,to_replace, replacement):
        try:
            x = x.replace(to_replace, replacement)
        except:
            pass
        return x
    
    